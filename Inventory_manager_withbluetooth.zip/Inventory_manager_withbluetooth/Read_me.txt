please upload INventory_manager_with_bluetooth,ino to ARdunio nano 

and 

Extract the zip file and copy the "ArduImageCapture" folder into your Arduino "tools" folder next to the Arduino "libraries" folder. If the "tools" folder doesn't exist, then you can create it yourself. 

also to use camera module you can follow this link 

https://circuitjournal.com/arduino-OV7670-to-pc